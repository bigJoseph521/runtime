from decimal import Decimal
import numpy as np
from collections import deque

from alphovex_sdk.indicators.base import BatchCalculationData

from alphovex_sdk import (
    PriceValue,
    Bar,
    SMA
)

class DummyBar:
    """Minimal Bar class for SMA testing."""
    def __init__(self, open_: float, high: float, low: float, close: float):
        self.open = open_
        self.high = high
        self.low = low
        self.close = close

    def get_price(self, price_type: str) -> Decimal:
        """Return the requested price."""
        if price_type == "open":
            return Decimal(self.open)
        elif price_type == "high":
            return Decimal(self.high)
        elif price_type == "low":
            return Decimal(self.low)
        elif price_type == "close":
            return Decimal(self.close)
        elif price_type == "typical":
            return Decimal((self.high + self.low + self.close) / 3)
        elif price_type == "weighted":
            return Decimal((self.high + self.low + 2 * self.close) / 4)
        else:
            raise ValueError(f"Invalid price_type: {price_type}")

sma = SMA(window_size=3, price_type="close")

bars = [
    DummyBar(Decimal(10), Decimal(12), Decimal(9), Decimal(11)),
    DummyBar(Decimal(10), Decimal(12), Decimal(9), Decimal(12)),
    DummyBar(Decimal(10), Decimal(12), Decimal(9), Decimal(13)),
]


for bar in bars:
    val = sma.update(bar)
    print(f"update() -> {val}")

print(sma.required_history)
print(sma.price_type)


def test_sma_calculate_one_symbol() -> None:
    sma = SMA(
        window_size=3,
        price_type="close"
    )

    data = BatchCalculationData(
        close = np.array([10,20,30,40,50])
    )

    value = sma.calculate(
        data=data,
        update_state=False
    )

    print(f"one symbol sma -> {value}")

test_sma_calculate_one_symbol()

def test_sma_calculate_multi_symbol() -> None:
    sma = SMA(
        window_size=3,
        price_type="close"
    )

    data = BatchCalculationData(
        close = np.array(
            [
                [10,20,30,40],
                [20,30,40,50],
                [30,40,50,60]
            ]
        ),
        symbols = ("AAPL", "MSFT", "NVDA")
    )

    value = sma.calculate(
        data=data,
        update_state=False
    )
    print(f"symbols -> {data.symbols[0]}")
    print(f"multi symbol smas -> {value}")

test_sma_calculate_multi_symbol()

